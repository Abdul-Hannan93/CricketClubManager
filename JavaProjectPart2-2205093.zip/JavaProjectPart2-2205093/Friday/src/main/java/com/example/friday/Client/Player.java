package com.example.friday.Client;


import javafx.beans.property.*;
import javafx.beans.value.ObservableValue;

import java.io.Serializable;

public class Player implements Serializable {

    private String name;
    private String country;
    private int age;
    private double heightInMeter;
    private String club;
    private String position;
    private int jerseyNumber;
    private int weeklySalary;

    public Player(String name, String country, int age, double height, String club, String position, int jerseyNumber,
                  int weeklySalary) {
        this.name = name;
        this.country = country;
        this.age = age;
        this.heightInMeter = height;
        this.club = club;
        this.position = position;
        this.jerseyNumber = jerseyNumber;
        this.weeklySalary = weeklySalary;
    }

    public String getName() {
        return this.name;
    }

    public String getCountry() {
        return this.country;
    }

    public int getAge() {
        return this.age;
    }

    public double getHeight() {
        return this.heightInMeter;
    }

    public String getClub() {
        return this.club;
    }

    public String getPosition() {
        return this.position;
    }

    public int getJerseyNumber() {
        return this.jerseyNumber;
    }

    public int getSalary() {
        return this.weeklySalary;
    }
    public int getWeeklySalary(){return this.weeklySalary;}
    public void setClub(String club)
    {
        this.club=club;
    }

    public String Filewrite() {
        if (this.jerseyNumber == -1)
            return this.name + "," + this.country + "," + this.age + "," + this.heightInMeter + "," + this.club + ","
                    + this.position + ",," + this.weeklySalary;
        else
            return this.name + "," + this.country + "," + this.age + "," + this.heightInMeter + "," + this.club + ","
                    + this.position + "," + this.jerseyNumber + "," + this.weeklySalary;

    }

    @Override
    public String toString() {
        if (this.jerseyNumber != -1)
            return "\nPlayer Name : " + this.name + "\nCountry is : " + this.country + "\nAge is : " + this.age
                    + "\nHeight is(in meter) : " + this.heightInMeter + "\nClub is : " + this.club + "\nPosition is : "
                    + this.position + "\nThe jersey number is : " + this.jerseyNumber + "\nWeekly Salary is : "
                    + this.weeklySalary + "\n\n\n";
        else
            return "\nPlayer Name : " + this.name + "\nCountry is : " + this.country + "\nAge is : " + this.age
                    + "\nHeight is(in meter) : " + this.heightInMeter + "\nClub is : " + this.club + "\nPosition is : "
                    + this.position + "\nThe jersey number is : Jersey Number is not available"
                    + "\nWeekly Salary is : " + this.weeklySalary + "\n\n\n";
    }

    public StringProperty nameProperty() {
        return new SimpleStringProperty(name);
    }

    public StringProperty countryProperty() {
        return new SimpleStringProperty(country);
    }


    public StringProperty clubProperty() {
        return new SimpleStringProperty(club);
    }

    public StringProperty positionProperty() {
        return new SimpleStringProperty(position);
    }


    public ObservableValue<String> ageProperty() {
        return new SimpleStringProperty(Integer.toString(age));
    }

    public ObservableValue<String> heightProperty() {
        return new SimpleStringProperty(Double.toString(heightInMeter));
    }

    public ObservableValue<String> salaryProperty() {
        return new SimpleStringProperty(Integer.toString(weeklySalary));
    }

    public ObservableValue<String> numberProperty() {
        return new SimpleStringProperty(Integer.toString(jerseyNumber));
    }
}
