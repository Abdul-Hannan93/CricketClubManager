package com.example.friday.Client;

import java.util.ArrayList;
import java.util.List;

public class ClubDataBase {
    public static List<Player> SearchByPlayerName(String playerName, List<Player> playerList)
    {
        List<Player> ret=new ArrayList<>();
        for (Player p : playerList) {
            if (p.getName().equalsIgnoreCase(playerName)) {
               ret.add(p);
                return ret;
            }
        }
        return ret;
    }
    public static List<Player> SearchByCountryName(String countryName,List<Player> playerList)
    {
        List<Player> ret=new ArrayList<>();
        for (Player p : playerList) {
            if (p.getCountry().equalsIgnoreCase(countryName)) {
                ret.add(p);

            }
        }
        return ret;

    }
    public static List<Player> SearchByPosition(String position,List<Player>playerList){
        List<Player> ret=new ArrayList<>();
        for(Player p:playerList){
            if(p.getPosition().equalsIgnoreCase(position)){
                ret.add(p);
            }
        }
        return ret;
    }
    public static List<Player> SearchBySalaryRange(int min,int max,List<Player>playerList){
        List<Player> ret=new ArrayList<>();
        for(Player p:playerList){
            if(min<=p.getSalary() && max>=p.getSalary()){
                ret.add(p);
            }
        }
        return ret;
    }
    public static Player getMaxSalaryPlayerInClub(List<Player>playerList) {
        Player max = null;
        for (Player p : playerList) {
            if (max == null || (p.getSalary() > max.getSalary())) {
                    max = p;

            }
        }
        return max;
    }
    public static Player getMaxAgePlayerInClub(List<Player>playerList) {
        Player max = null;
        for (Player p : playerList) {
            if (max == null || (p.getAge() > max.getAge())) {
                max = p;

            }
        }
        return max;
    }
    public static Player getMaxHeightPlayerInClub(List<Player>playerList) {
        Player max = null;
        for (Player p : playerList) {
            if (max == null || (p.getHeight() > max.getHeight())) {
                max = p;

            }
        }
        return max;
    }
    public static long TotalSalary(List<Player>playerlist){
        long total=0;
        for(Player p:playerlist){
            total+=p.getSalary()*52;
        }
        return total;
    }



}
