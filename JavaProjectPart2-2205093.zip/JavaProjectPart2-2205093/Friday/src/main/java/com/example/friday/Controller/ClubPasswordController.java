package com.example.friday.Controller;

import com.example.friday.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class ClubPasswordController {
    Stage stage;
    Main main;
    String club;
    public void setStage(Stage stage)
    {
        this.stage=stage;
    }
    public void setMain(Main main)
    {
        this.main=main;

    }
    public void setClubing(String club)
    {
        this.club=club;
    }
    @FXML
    private TextField oldPasswordField;

    @FXML
    private TextField newPasswordField;

    @FXML
    private Text messageLabel;

    private Map<String, String> clubPasswordMap = new HashMap<>();

    private void loadClubData() {
        try (BufferedReader reader = new BufferedReader(new FileReader("password.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    clubPasswordMap.put(parts[0].trim(), parts[1].trim());
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            messageLabel.setText("Error loading club data.");
        }
    }

    @FXML
    private void handleChangePassword() {
        String oldPassword = oldPasswordField.getText();
        String newPassword = newPasswordField.getText();

        if ( oldPassword.isEmpty() || newPassword.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        if (clubPasswordMap.containsKey(club) && clubPasswordMap.get(club).equals(oldPassword)) {
            clubPasswordMap.put(club, newPassword);
            updatePasswordFile();

            messageLabel.setText("Password changed successfully!");
        } else {
            messageLabel.setText("Incorrect old password.");
        }
    }

    private void updatePasswordFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("password.txt"))) {
            for (Map.Entry<String, String> entry : clubPasswordMap.entrySet()) {
                writer.write(entry.getKey() + "," + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            messageLabel.setText("Error updating password file.");
        }
    }
    @FXML
    private void initialize() {
        loadClubData();
    }


    public void BackToHomepage(ActionEvent actionEvent) throws Exception {
        main.showHomePage(club);
    }
}
